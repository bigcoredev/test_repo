<div class="ps-comments__input-addon ps-comments__input-addon--files ps-js-addon-files"
        style="width:auto; padding-right:25px; display:none">
    <span class="ps-js-filename" alt="file"></span>

	<div class="ps-loading ps-js-loading">
		<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" alt="loading" />
	</div>

	<div class="ps-comments__input-addon-remove ps-js-remove">
		<i class="gcis gci-times"></i>
	</div>
</div>
