<div 
  class="ps-file-item-wrapper ps-js-file"
  data-id="<?php echo $id; ?>" 
  data-file-url="<?php echo wp_get_attachment_url($id); ?>"
  data-extension="<?php echo $extension; ?>"
>
  <div class="ps-file-item-content">
    <div class="ps-file-item-content__icon ps-file-item-content__icon--<?php echo strtolower($extension);?>">
      <div class="ps-file-item-content__icon-image">
        <?php echo $extension; ?>
      </div>
    </div>

    <div class="ps-file-item-content__details">
      <div class="ps-file-item-content__name" title="<?php echo $name; ?>"><?php echo $name; ?></div>
      <div class="ps-file-item-content__size"><?php echo $size; ?></div>
    </div>
  </div>
  <div class="ps-file-item-action">
    <a class="ps-tip ps-tip--arrow"
      aria-label="<?php echo __('Download', 'peepsofileuploads'); ?>"
      data-id="<?php echo $id; ?>"
      onclick="downloadModel('<?php echo wp_get_attachment_url($id);?>')"><i class="gcis gci-download"></i>
    </a>
    <?php if ($can_delete): ?>
    <a class="ps-tip ps-tip--arrow ps-js-file-delete"
      aria-label="<?php echo __('Delete', 'peepsofileuploads'); ?>" href="#">
      <i class="gcis gci-trash"></i>
    </a>
    <?php endif; ?>
  </div>
</div>
<!-- Here Is Section to show 3D model -->
<div>
  <?php
    $viewable_extensions = ["fbx", "stl", "3dm", "obj", "ply", "3d", "plyx", "stlx", "drc"];
    if (in_array(strtolower($extension), $viewable_extensions)): ?>
     <button 
        onclick="open3DModelDialog('<?php echo wp_get_attachment_url($id);?>')"
        style="padding: 4px 8px; font-size:1em;"
        class="ps-js-view-model"
        >View 3D Model
    </button>
    <?php endif; ?>
</div>

